package com.example.hp1.finalapplication;

/**
 * Created by Hp1 on 27/09/2017.
 */

public class lvtepul {
    private String title;
    private int imageid;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImageid() {
        return imageid;
    }

    public void setImageid(int imageid) {
        this.imageid = imageid;
    }

    public lvtepul(String title, int imageid) {
        this.title = title;
        this.imageid = imageid;





    }
}
