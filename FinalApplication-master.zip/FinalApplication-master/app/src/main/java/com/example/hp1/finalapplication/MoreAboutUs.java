package com.example.hp1.finalapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MoreAboutUs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_about_us);
    }
}
